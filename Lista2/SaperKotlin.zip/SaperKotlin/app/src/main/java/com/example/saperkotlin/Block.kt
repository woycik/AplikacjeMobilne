package com.example.saperkotlin
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.widget.AppCompatButton

@SuppressLint("ViewConstructor")
class Block (context: Context?, val xCoordinate: Int, val yCoordinate: Int):AppCompatButton(context!!)
{
    var isMined = false
    var isFlagged = false
    var click = true
    var isVisited =false


    fun setNumberOfSurroundingMines(num: Int) {
            this.click = false
            setBackgroundColor(Color.rgb(192, 181, 181))
            if (num != 0) {
                this.text = num.toString()
                when (num) {
                    1 -> this.setTextColor(Color.BLUE)
                    2 -> this.setTextColor(Color.CYAN)
                    3 -> this.setTextColor(Color.GREEN)
                    4 -> this.setTextColor(Color.MAGENTA)
                    5 -> this.setTextColor(Color.RED)
                    6 -> this.setTextColor(Color.YELLOW)
                    7 -> this.setTextColor(Color.BLACK)
                    8 -> this.setTextColor(Color.DKGRAY)
                }
            }

    }

    fun setValues() {
        setBackgroundColor(Color.rgb(230, 227, 227))
        this.scaleX = 0.75f
        this.scaleY = 0.8f
        this.textSize = 16f
        this.setTypeface(null, Typeface.BOLD)
    }

    fun setFlag() {
        setPadding(5, 5, 5, 5)
        setBackgroundResource(R.drawable.flags_foreground)
    }

    fun setMineIcon() {
        if (isMined ) {
            setPadding(5, 5, 5, 5)
            setBackgroundResource(R.drawable.minesweeper)
        }
    }


    fun clearFlag() {
        isFlagged = false
        setBackgroundResource(0)
        setBackgroundColor(Color.rgb(230, 227, 227))
    }



}