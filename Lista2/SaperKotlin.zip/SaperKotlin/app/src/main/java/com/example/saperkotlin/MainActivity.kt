package com.example.saperkotlin

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.view.View.OnLongClickListener
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {
    private var block: Array<Array<Block?>>? = null
    private val size = 9
    var endGameimg: ImageView? = null
    private var start = false
    private var numberOfMinesOnBoard = 0
    private var numberOfMines = 5
    private var numberOfFlagsToUse = 0
    var numberOfFlags: TextView? = null
    var startButton: Button? = null
    var flagImg : ImageView?= null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        numberOfFlags = findViewById<TextView>(R.id.numberOfFlags)
        startButton = findViewById<Button>(R.id.startButton)
        endGameimg = findViewById<ImageView>(R.id.endGameImg)
        flagImg = findViewById<ImageView>(R.id.flagImg)
        startButton!!.text = "Start new game"
        endGameimg!!.visibility = View.VISIBLE
        endGameimg!!.setBackgroundResource(R.drawable.minesweeper)
        startButton!!.setOnClickListener {
            startNewGame()
            flagImg!!.visibility=View.VISIBLE
            startButton!!.visibility = View.INVISIBLE
            endGameimg!!.setBackgroundResource(0)
        }
    }

    fun startNewGame() {
        block = Array<Array<Block?>>(size) { arrayOfNulls<Block>(size) }
        endPreviousGame()
        prepareBoard()
        showBoard()
        numberOfFlags!!.text = ""
    }

    fun endPreviousGame() {
        numberOfMinesOnBoard = 0
        numberOfFlagsToUse = 0
        start = false
    }

    fun prepareBoard() {
        for (x in 0 .. size-1) {
            for (y in 0 .. size-1) {
                block!![x][y] = Block(this, x, y)
                block!![x][y]!!.setValues()
                block!![x][y]!!.setOnLongClickListener(OnLongClickListener {
                    val currBlock: Block? = block!![x][y]
                    if (start) {
                        if (currBlock!!.click) {
                            if (!currBlock.isFlagged) {
                                currBlock.setFlag()
                                currBlock.click = false
                                currBlock.isFlagged = true
                                numberOfFlagsToUse--
                            }
                        } else if (!currBlock.click && currBlock.isFlagged) {
                            currBlock.clearFlag()
                            currBlock.click = true
                            currBlock.isFlagged = false
                            numberOfFlagsToUse++
                        }
                        numberOfFlags!!.text = Integer.toString(numberOfFlagsToUse)
                    }
                    gameWon()
                    true
                })
                block!![x][y]!!.setOnClickListener(View.OnClickListener {
                    val currBlock: Block? = block!![x][y]
                    if (!start) {
                        setMines(x, y)
                        numberOfFlags!!.text = Integer.toString(numberOfFlagsToUse)
                        start = true
                    }
                    if (currBlock!!.click && !currBlock.isFlagged) {
                        if (currBlock.isMined) {
                            currBlock.setBackgroundColor(Color.rgb(238, 166, 166))
                            showAllMines()
                            gameOver()
                        } else {
                            showFields(x, y)
                        }
                    }
                    gameWon()
                })
            }
        }
    }

    fun checkIfBoardIsFilled(): Boolean {
        for (i in 0 .. size-1) {
            for (j in 0 .. size-1) {
                if (block!![i][j]!!.click && !block!![i][j]!!.isMined) {
                    return false
                }
            }
        }
        return true
    }

    fun gameWon() {
        if (numberOfFlagsToUse == 0) {
            if (checkIfBoardIsFilled()) {
                endGame()
                endGameimg!!.setBackgroundResource(R.drawable.win)
                endGameimg!!.visibility = View.VISIBLE
            }
        }
    }

    fun gameOver() {
        endGame()
        endGameimg!!.setBackgroundResource(R.drawable.gameover)
        endGameimg!!.visibility = View.VISIBLE
    }

    fun endGame() {
        for (i in 0 .. size-1) {
            for (j in 0 .. size-1) {
                block!![i][j]!!.setVisibility(View.GONE)
                block!![i][j] = null
            }
        }
        block = null
        startButton!!.text = "Restart"
        startButton!!.visibility = View.VISIBLE
        startButton!!.setOnClickListener {
            endGameimg!!.setBackgroundResource(0)
            startButton!!.visibility = View.INVISIBLE
            startNewGame()
        }
    }

    fun showFields(x: Int, y: Int) {
        val neighbours: ArrayList<Block?>
        block!![x][y]!!.isVisited = true
        val numOfSurroundings = numberOfSurroundingMines(x, y)
        block!![x][y]!!.setNumberOfSurroundingMines(numOfSurroundings)
        if (numOfSurroundings == 0) {
            neighbours = getNeighbours(x, y)
            if (!neighbours.isEmpty()) {
                for (blocks in neighbours) {
                    val blockX: Int = blocks!!.xCoordinate
                    val blockY: Int = blocks!!.yCoordinate
                    val num = numberOfSurroundingMines(blockX, blockY)
                    block!![blockX][blockY]!!.setNumberOfSurroundingMines(num)
                    if (num == 0 && !block!![blockX][blockY]!!.isVisited) {
                        showFields(blockX, blockY)
                    }
                }
            }
        }
    }

    fun getNeighbours(x: Int, y: Int): ArrayList<Block?> {
        val b: ArrayList<Block?> = ArrayList<Block?>()
        for (i in -1..1) {
            for (j in -1..1) {
                if (isInBoard(x + i, y + j)) {
                    val currBlock: Block? = block!![x + i][y + j]
                    if (!currBlock!!.isMined && (i != 0 || j != 0)) {
                        b.add(currBlock)
                    }
                }
            }
        }
        return b
    }

    fun showBoard() {
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val width = displayMetrics.widthPixels
        val tableLayout = findViewById<View>(R.id.tableLayout) as TableLayout
        for (j in 0 until size) {
            val row = TableRow(this)
            for (i in 0 until size) {
                block!![j][i]!!.setLayoutParams(TableRow.LayoutParams(width / (size+1), width / (size+1)))
                row.addView(block!![j][i])
            }
            tableLayout.addView(row, TableLayout.LayoutParams(width / (size+1), width / (size+1)))
        }
    }

    fun showAllMines() {
        for (x in 0 .. size-1) {
            for (y in 0 .. size-1) {
                if (block!![x][y]!!.isMined) {
                    block!![x][y]!!.setMineIcon()
                }
            }
        }
    }

    fun isInBoard(x: Int, y: Int): Boolean {
        return x >= 0 && (x < size && y >= 0 && y < size)
    }

    fun numberOfSurroundingMines(currentX: Int, currentY: Int): Int {
        var num = 0
        for (i in -1..1) {
            for (j in -1..1) {
                if (isInBoard(currentX + i, currentY + j)) {
                    if (block!![currentX + i][currentY + j]!!.isMined) {
                        num++
                    }
                }
            }
        }
        return num
    }

    fun setMines(x: Int, y: Int) {
        val rand = Random()
        while (numberOfMinesOnBoard < numberOfMines) {
            val x1 = rand.nextInt(9)
            val y1 = rand.nextInt(9)
            if (x != x1 || y != y1) {
                val currBlock: Block? = block!![x1][y1]
                if (!currBlock!!.isMined) {
                    currBlock.isMined = true
                    numberOfMinesOnBoard++
                }
            }
        }
        numberOfFlagsToUse = numberOfMinesOnBoard
    }
}