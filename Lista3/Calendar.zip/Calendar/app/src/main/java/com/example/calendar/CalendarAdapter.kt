package com.example.calendar;


import android.graphics.Color
import android.view.LayoutInflater
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class CalendarAdapter(private val dataSet: ArrayList<String>,val onBlockListener : OnBlockClickListener) : RecyclerView.Adapter<CalendarViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CalendarViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.block,parent,false)
        view.layoutParams.height = 200
        return CalendarViewHolder(view,onBlockListener)
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }

    override fun onBindViewHolder(holder: CalendarViewHolder, position: Int) {
        if(dataSet[position].contains(" ")){
            dataSet[position].replace(" ","")
            holder.layout.setBackgroundResource(R.drawable.rounded_rectangles)
        }
        holder.date.text = dataSet[position]
    }


    interface OnBlockClickListener {
        fun onBlockClick(position: Int, date: String)

    }




}