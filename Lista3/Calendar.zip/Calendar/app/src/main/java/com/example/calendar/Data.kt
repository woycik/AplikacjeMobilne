package com.example.calendar

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "data")
data class Data(
    @PrimaryKey(autoGenerate = true)  val id: Int=0,
    val time: String,
    val event: String,
    val url: String
)
