package com.example.calendar

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder

class DayActivities : AppCompatActivity() ,DayActivitiesAdapter.OnCellClickListener{

    lateinit var rv : RecyclerView
    var event : ArrayList<Event> = ArrayList<Event>()
    var day : Int =0
    var month : Int = 0
    var year : Int = 0

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dayactivity)
        val button = findViewById<Button>(R.id.backButton)
        getInputFromIntent()
        setView()
        unableSwipaActions()
        addActivity()
        button.setOnClickListener {
            rememberContent()
        }
    }

    private fun getInputFromIntent(){
        val header = findViewById<TextView>(R.id.textView2)
        val evenInput = intent.getSerializableExtra("event")
        val date = intent.getStringExtra("date")

        day = intent.getIntExtra("day",0)
        month = intent.getIntExtra("month",0)
        year = intent.getIntExtra("year",0)
        header.text = date
        if(evenInput != null){
            event = evenInput as ArrayList<Event>
        }
    }



    private fun rememberContent() {
        val newIntent = Intent()
        newIntent.putExtra("event",event)
        newIntent.putExtra("day",day)
        newIntent.putExtra("month",month)
        newIntent.putExtra("year",year)
        setResult(Activity.RESULT_OK,newIntent)
        finish()
    }


    private fun unableSwipaActions() {
        val helper = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            @SuppressLint("NotifyDataSetChanged")
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                when(direction){
                    ItemTouchHelper.RIGHT->{}
                    ItemTouchHelper.LEFT-> {
                        event.removeAt(viewHolder.adapterPosition)
                        rv.adapter?.notifyItemRemoved(viewHolder.adapterPosition)
                        rv.adapter?.notifyItemRangeChanged(viewHolder.adapterPosition,event.size)
                        rv.adapter?.notifyDataSetChanged()
                    }
                }

            }



        }
        val itemTouchHelper = ItemTouchHelper(helper)
        itemTouchHelper.attachToRecyclerView(rv)
    }



    fun setView(){
        rv = findViewById<RecyclerView>(R.id.recyclerView)
        rv.layoutManager = GridLayoutManager(applicationContext,1)
        rv.adapter = DayActivitiesAdapter(event,this)

    }

    fun addActivity(){
        val plusButton = findViewById<Button>(R.id.plusButtton)
        plusButton.setOnClickListener {
            val addAdtivityIntent = Intent(applicationContext,ActivityItem::class.java)
            addAdtivityIntent.putExtra("day",day)
            addAdtivityIntent.putExtra("month",month)
            addAdtivityIntent.putExtra("year",year)
            resultLauncher.launch(addAdtivityIntent)
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        result-> val data = result.data
        if (data != null) {
            data.getSerializableExtra("event")?.let { event.add(it as Event) }
            rv.adapter?.notifyItemChanged(event.size)

        }
    }

    override fun onCellClick(position: Int) {
        val intent = Intent(applicationContext,DetailedInformation::class.java)
        if(event.isNotEmpty()) {
            intent.putExtra("event", event[position])
        }
        startActivity(intent)

    }


}