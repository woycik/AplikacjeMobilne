package com.example.calendar

import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso


class DayActivitiesAdapter(val event : ArrayList<Event>,val onCellClickListener: OnCellClickListener) : RecyclerView.Adapter<DayActivitiesViewHolder>()  {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayActivitiesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.day_activity_cell,parent,false)
        view.layoutParams.height = (parent.layoutParams.height*0.2).toInt()
        return DayActivitiesViewHolder(view, onCellClickListener)
    }

    override fun onBindViewHolder(holder: DayActivitiesViewHolder, position: Int) {
        holder.hour.text = event[position].time
        holder.url = event[position].url
        holder.activity.text = event[position].data
    }

    override fun getItemCount(): Int {
        return event.size
    }

    interface OnCellClickListener{
        fun onCellClick(position: Int)
    }



}