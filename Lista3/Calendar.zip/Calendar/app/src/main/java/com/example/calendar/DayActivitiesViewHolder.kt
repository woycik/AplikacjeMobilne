package com.example.calendar

import android.content.Intent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class DayActivitiesViewHolder(val view : View,var onCellClickListener: DayActivitiesAdapter.OnCellClickListener) : RecyclerView.ViewHolder(view), View.OnClickListener {

    val hour : TextView
    var activity : TextView
    val imgView : ImageView
    var url : String= ""

    init{
        hour=view.findViewById<TextView>(R.id.hour)
        activity =view.findViewById<TextView>(R.id.activityData)
        view.setOnClickListener(this)
        imgView  = view.findViewById(R.id.imageView)

    }

    override fun onClick(v: View?) {

        onCellClickListener.onCellClick(adapterPosition)

    }
}