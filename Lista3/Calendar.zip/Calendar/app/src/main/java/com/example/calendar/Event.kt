package com.example.calendar

class Event (year: Int,month:Int,day:Int,time : String, data : String,url :String) : java.io.Serializable{
    var year : Int
    var month : Int
    var day : Int
    var time : String
    var data : String
    var url : String
    init {
        this.data = data
        this.day = day
        this.time = time
        this.url = url
        this.month = month
        this.year = year
    }
}