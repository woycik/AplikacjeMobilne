package com.example.calendar

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity

class ActivityItem : AppCompatActivity() {
    var month : Int = 0
    var year : Int =0
    var day  : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.addactivity)
        val backButton = findViewById<Button>(R.id.backButton1)
        val addButton = findViewById<Button>(R.id.addActivityButton)
        day = intent.getIntExtra("day",0)
        month = intent.getIntExtra("month",0)
        year = intent.getIntExtra("year",0)
        Log.e("date",day.toString())
        Log.e("date",month.toString())
        Log.e("date",year.toString())
        backButton.setOnClickListener {
            finish()
        }
        addButton.setOnClickListener {
            addActivity()
        }
    }

    @SuppressLint("CutPasteId")
    private fun addActivity() {
        val newIntent = Intent()
        val time = findViewById<TimePicker>(R.id.getTime)
        val activityData = findViewById<EditText>(R.id.getData)
        val urlValue = findViewById<EditText>(R.id.getUrl)
        var selectedHour = time.hour
        var selectedMinute = time.minute
        val event = Event(year,month,day,selectedHour.toString()+":"+selectedMinute.toString(),activityData.text.toString(),urlValue.text.toString())
        newIntent.putExtra("event",event)
        setResult(Activity.RESULT_OK,newIntent)
        finish()
    }
}