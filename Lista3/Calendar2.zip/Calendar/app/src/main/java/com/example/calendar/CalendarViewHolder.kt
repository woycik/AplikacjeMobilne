package com.example.calendar

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class CalendarViewHolder(val view : View,var onBlockListener : CalendarAdapter.OnBlockClickListener) : RecyclerView.ViewHolder(view),View.OnClickListener{
    val date : TextView
    val layout : ConstraintLayout

    init{
        date=view.findViewById<TextView>(R.id.date)
        layout = view.findViewById(R.id.layout)
        view.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        onBlockListener.onBlockClick(adapterPosition, date.text.toString())
    }


}
