package com.example.calendar

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso

class DetailedInformation : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detailed_info)
        val backButton = findViewById<Button>(R.id.back)
        val activityText = findViewById<TextView>(R.id.data)
        val hourText = findViewById<TextView>(R.id.hour1)
        val url = findViewById<ImageView>(R.id.imageView2)
        backButton.setOnClickListener {
            finish()
        }
        val event =  intent.getSerializableExtra("event") as? Event
        if(event != null) {
            hourText.text = event.time
            activityText.text = event.data


            val urlText = event.url
            if (urlText != "") {
                Picasso.get().load(urlText).into(url)
            } else {
                val imgText = findViewById<TextView>(R.id.img)
                imgText.visibility = View.GONE;
            }
        }
    }
}