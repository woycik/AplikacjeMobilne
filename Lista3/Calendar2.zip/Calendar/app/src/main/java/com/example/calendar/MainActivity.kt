package com.example.calendar

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import androidx.room.RoomDatabase
import java.time.LocalDate
import java.time.Year
import java.time.YearMonth
import java.time.format.DateTimeFormatter

class MainActivity : AppCompatActivity(),CalendarAdapter.OnBlockClickListener {
    lateinit var rv : RecyclerView
    var currentPosition : Int = 0
    var listOfEvents : ArrayList<Event> = ArrayList<Event>()
    lateinit var header : TextView
    lateinit var days : ArrayList<String>
    lateinit var nextMonth : Button
    lateinit var prevMonth : Button
    var today = LocalDate.now()
    var selectedDate = LocalDate.now()
    var indeksOfFirstDay =0
    lateinit var db: AppDatabase





    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getInstance()
        setOnClick()
        setMonthView()
        setView()
    }

    fun getInstance(){
        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "my_database"
        ).allowMainThreadQueries().build()
    }

    fun addToDataBase( list : ArrayList<Event>){
        val dataDao = db.dataDao()
        for(e in list){
            val data = Data(0,e.time,e.data,e.url)
            dataDao.insert(data)
        }
        val dataList = dataDao.getAll()

        // wyświetlenie danych na ekranie
        dataList.forEach { data ->
            Log.d("Data", "id: ${data.id}, time: ${data.time}, event: ${data.event}, url: ${data.url}")
        }
    }

    override fun onResume() {
        super.onResume()
        sendNotification()
        addToDataBase(listOfEvents)
    }


    fun setOnClick(){
        nextMonth = findViewById(R.id.next)
        prevMonth = findViewById(R.id.prev)
        nextMonth.setOnClickListener {
            selectedDate = selectedDate.plusMonths(1)
            setMonthView()
            setView()
        }
        prevMonth.setOnClickListener {
            selectedDate  = selectedDate.minusMonths(1)
            setMonthView()
            setView()
        }
    }

    fun setMonthView(){
        header = findViewById(R.id.monthYear)
        header.text  = createHeader(selectedDate)
        days = prepareDaysArray(selectedDate)

    }



    fun prepareDaysArray(date: LocalDate): ArrayList<String>{
        val tempAray = ArrayList<String>()
        val month = YearMonth.from(date)
        val firstDayOfSelectedMonth = selectedDate.withDayOfMonth(1)
        indeksOfFirstDay = firstDayOfSelectedMonth.dayOfWeek.value
        val lengthOfMonth = month.lengthOfMonth()
        for(i in 1..42){
            if(i<indeksOfFirstDay || i>=lengthOfMonth+indeksOfFirstDay){
                tempAray.add("")
            }
            else{
                if(today.dayOfMonth == i-indeksOfFirstDay+1  && today.month.value==date.monthValue && today.year ==date.year){
                    val todayCell =(i-indeksOfFirstDay+1).toString() + " "
                    tempAray.add(todayCell)
                }
                else {
                    tempAray.add((i - indeksOfFirstDay + 1).toString())
                }
            }

        }
        return  tempAray
    }

    private fun createHeader(date: LocalDate): String {
        val formatter = DateTimeFormatter.ofPattern("MMMM yyyy")
        return date.format(formatter)
    }

    private fun dayAndMonth(date: LocalDate): String {
        val formatter = DateTimeFormatter.ofPattern("dd MMMM   yyyy")
        return date.format(formatter)
    }


    fun setView(){
        rv = findViewById<RecyclerView>(R.id.RecyclerView)
        rv.layoutManager = GridLayoutManager(applicationContext,7)
        rv.adapter = CalendarAdapter(days,this)


    }

    override fun onBlockClick(position: Int, date: String) {

        val intent = Intent(applicationContext,DayActivities::class.java)
        currentPosition = position
        val selectedMonth = selectedDate.withDayOfMonth(currentPosition-indeksOfFirstDay+2)
        selectedDate = selectedDate.withDayOfMonth(currentPosition-indeksOfFirstDay+2)
        val year = Year.from(selectedMonth).value
        val month= YearMonth.from(selectedMonth).monthValue
        if(year>=0) {
            val list = ArrayList<Event>()
            for(i in listOfEvents){
                if(i.day == (currentPosition -indeksOfFirstDay+2)  && i.month ==month && i.year ==year){
                    list.add(i)
                    listOfEvents.remove(i)
                }
            }
            intent.putExtra("event",list)
            intent.putExtra("day",currentPosition -indeksOfFirstDay+2)
            intent.putExtra("month",month)
            intent.putExtra("year",year)
            intent.putExtra("date",dayAndMonth(selectedDate))

        }
        resultLauncher.launch(intent)
    }

    @SuppressLint("NotifyDataSetChanged")
    var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            result-> val data = result.data
        if (data != null) {
            data.getSerializableExtra("event")?.let { listOfEvents.addAll(it as ArrayList<Event> ) }

        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putSerializable("event1",listOfEvents)

    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val events  = savedInstanceState.getSerializable("event1") as? ArrayList<Event>
        if (events != null) {
            listOfEvents = events
        }
    }

    fun sendNotification(){
        val dayToday = today.dayOfMonth
        val monthToday = today.month.value
        Log.e("tag",dayToday.toString())
        for(e in listOfEvents){
            if(e.day ==dayToday+1 && e.month == monthToday && e.notificated==false){
                e.notificated=true
                val notificationHelper = Notifications(this)
                notificationHelper.sendNotification("Incoming event",
                   e.data
                )
            }
        }
    }


}