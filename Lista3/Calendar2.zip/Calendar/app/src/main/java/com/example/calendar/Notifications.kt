package com.example.calendar

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import kotlin.math.absoluteValue


class Notifications(private val context: Context) {

    var sharedPreferences = context.getSharedPreferences("PREFERENCE_NAME",Context.MODE_PRIVATE)

    var today = LocalDate.now().dayOfYear.absoluteValue

    val check = sharedPreferences.getInt("day",-1)

        private val notificationManager: NotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        fun sendNotification(title: String, message: String) {
            if(true)
            {
                val channelId = "channel"

                val channel = NotificationChannel(
                    channelId,
                    "channel",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                notificationManager.createNotificationChannel(channel)

                val notificationBuilder = NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(R.mipmap.calendar_icon)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)

                notificationManager.notify(0, notificationBuilder.build())

                val sender = sharedPreferences.edit()
                sender.putInt("day",today)
                sender.apply()
        }
    }
}