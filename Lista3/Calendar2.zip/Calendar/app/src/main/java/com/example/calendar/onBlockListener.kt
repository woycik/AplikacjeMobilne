package com.example.calendar

interface onBlockListener {
    fun onBlockClick(position : Int,date:String)

}