package com.example.gallery

class Images(path : String, data : String) : java.io.Serializable{
    var path = path
    var data = data
    var rate : Float = 0F
}