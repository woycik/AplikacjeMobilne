package com.example.gallery

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class Camera : AppCompatActivity() {

    private lateinit var cameraExecutor : ExecutorService
    private lateinit var savedFilePath : String
    lateinit var addButton : Button


    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.camera)
        savedFilePath = getOutputDirectory().absolutePath + File.separator + "${System.currentTimeMillis()}.jpg"
        cameraExecutor = Executors.newSingleThreadExecutor()
        addButton = findViewById(R.id.add)

        requestPermission()

    }

    private fun requestPermission() {
        requestCameraPermissionIfMissing { granted ->
            if(granted){
                startCamera()
            }
        }
    }

    private fun startCamera() {
        val cameraProvider = ProcessCameraProvider.getInstance(this)
        cameraProvider.addListener({
            val camera = cameraProvider.get()
            val imageCapture = ImageCapture.Builder().build()
            runOnUiThread {
                camera.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, imageCapture)
                addButton.setOnClickListener {
                    onClick(imageCapture)
                    finish()
                }
            }
        },cameraExecutor)
    }

    fun onClick(imageCapture : ImageCapture) {
        val outputFileOptions = ImageCapture.OutputFileOptions.Builder(File(savedFilePath)).build()
        imageCapture.takePicture(outputFileOptions, cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(error: ImageCaptureException)
                {
                    // Handle error
                }
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val savedUri = outputFileResults.savedUri ?: Uri.fromFile(File(savedFilePath))
                    val savedFile = File(savedUri.path!!)
                    saveImage(savedUri)
                }
            })
    }

    // Get the output directory for saving images
    private fun getOutputDirectory(): File {
        val mediaDirs = externalMediaDirs
        val mediaDir = mediaDirs.firstOrNull()?.let {
            File(it, resources.getString(R.string.app_name)).apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists())
            mediaDir else filesDir
    }


    private fun saveImage(uri: Uri) {
        val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
        val cw = ContextWrapper(this)
        val directory = cw.getDir("imageDir", Context.MODE_PRIVATE)
        val fileName = "${System.currentTimeMillis()}.jpg"
        val myImageFile = File(directory, fileName)

        val outputStream = FileOutputStream(myImageFile)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
        outputStream.flush()
        outputStream.close()
    }



    private fun requestCameraPermissionIfMissing(onResult: ((Boolean) -> Unit)) {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
            onResult(true)
        } else {
            val requestPermissionLauncher = registerForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { isGranted: Boolean ->
                onResult(isGranted)
            }
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }
}