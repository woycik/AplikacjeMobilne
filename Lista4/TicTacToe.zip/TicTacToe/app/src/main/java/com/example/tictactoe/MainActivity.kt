package com.example.tictactoe

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.Center
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tictactoe.ui.theme.TicTacToeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TicTacToeTheme {
                Surface(modifier = Modifier.fillMaxSize(),
                ) {
                    box()
                    }
                }

            }
        }
    }


@Composable
fun box(){
    val viewModel = remember { TicTacToeViewModel() }
    TicTacToeGame(viewModel)

}


@Composable
fun TicTacToeGame(viewModel : TicTacToeViewModel) {

    val boardSize = viewModel.boardSize
    val board = viewModel.board

    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp


    Column(modifier =  Modifier.background(androidx.compose.ui.graphics.Color.LightGray)) {
        Text(text = "TicTacToe Game",fontSize = 40.sp, color = Color.Blue, modifier = Modifier
            .align((CenterHorizontally))
            .padding(15.dp))


        for (i in 0 until boardSize) {
            Row {
                for (j in 0 until boardSize) {
                    Box(
                        modifier = Modifier
                            .size(screenWidth / boardSize)
                            .clickable {
                                viewModel.onCellClicked(i, j)
                            }
                            .padding(5.dp)
                            .background(androidx.compose.ui.graphics.Color.White)
                    ) {
                        val cellState = board[i][j]
                        if (cellState == State.CROSS) {
                            Cross(Modifier.fillMaxSize())
                        } else if (cellState == State.CIRCLE) {
                            Circle(Modifier.fillMaxSize())
                        }
                    }
                }
            }
        }
        Text(text = viewModel.winner, fontSize = 30.sp, modifier = Modifier.align(CenterHorizontally))


        var showMenu by remember { mutableStateOf(false) }
        val options = listOf(3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)
        var selectedIndex by remember { mutableStateOf(0) }

        Box(
            modifier = Modifier
                .align(CenterHorizontally)
                .width(50.dp)
                .height(50.dp)
                .clickable(onClick = { showMenu = true }

                )
        ) {
            Text(text = options[selectedIndex].toString(), modifier = Modifier.align(Center))
            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                options.forEachIndexed { index, option ->
                    DropdownMenuItem(onClick = {
                        selectedIndex = index
                        showMenu = false
                        viewModel.onNumberClick(option)
                    }) {
                        Text(option.toString())
                    }
                }
            }
        }

        Button(
            onClick = { viewModel.resetGame() },
            modifier = Modifier
                .padding(vertical = 16.dp)
                .align(CenterHorizontally)
        ) {
            Text("Reset game")
        }
    }
}

@Composable
fun Cross(modifier: Modifier) {
    Box(modifier.rotate(45f)) {
        Box(
            Modifier
                .fillMaxHeight()
                .width(2.dp)
                .background(androidx.compose.ui.graphics.Color.Black)
                .rotate(45f)
                .align((Alignment.Center))

        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(androidx.compose.ui.graphics.Color.Black)
                .rotate(45f)
                .align((Alignment.Center))

        )
    }
}

@Composable
fun Circle(modifier: Modifier) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(50.dp)
                .background(androidx.compose.ui.graphics.Color.Black, shape = CircleShape)
        )
    }
}


