package com.example.tictactoe

enum class State {
    EMPTY,
    CROSS,
    CIRCLE
}