package com.example.tictactoe

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class TicTacToeViewModel : ViewModel() {

    private val _boardSize = mutableStateOf(3)
    val boardSize: Int
        get() = _boardSize.value

    private val _board = mutableStateOf(
        List(boardSize) { List(boardSize) { State.EMPTY } }
    )
    val board: List<List<State>>
        get() = _board.value

    private val _currentPlayer = mutableStateOf(State.CIRCLE)
    val currentPlayer: State
        get() = _currentPlayer.value

    private val _winner = mutableStateOf("")
    val winner : String
        get() = _winner.value


    init{
        resetGame()
    }

    fun onCellClicked(row: Int, col: Int) {
        if (board[row][col] == State.EMPTY) {
            val newBoard = _board.value.toMutableList()
            newBoard[row] = newBoard[row].toMutableList().apply { set(col, currentPlayer) }
            _board.value = newBoard
            _currentPlayer.value = if (currentPlayer == State.CROSS) {
                State.CIRCLE
            } else {
                State.CROSS
            }
        }
        updateWinner()
    }

    fun onNumberClick(number : Int){
        _boardSize.value = number
        resetGame()
    }

    fun resetGame() {
        _winner.value = ""
        _board.value = List(boardSize) { List(boardSize) { State.EMPTY } }
        _currentPlayer.value = State.CROSS
    }

    fun checkBoard(state : State): Boolean {
        for (i in 0 until boardSize) {
            for (j in 0 until boardSize) {

                if (j<=boardSize-3 && board[i][j] == state && board[i][j+1] == state && board[i][j+2] == state) {
                    return true
                }

                if (i<=boardSize-3 && board[i][j] == state && board[i+1][j] == state && board[i+2][j] == state) {
                    return true
                }

                if (i<=boardSize-3 && j<=boardSize-3 && board[i][j] == state && board[i+1][j+1] == state && board[i+2][j+2] == state) {
                    return true
                }

                if (i>1 && j<=boardSize-3  && board[i][j] == state && board[i-1][j+1] == state && board[i-2][j+2] == state) {
                    return true
                }
            }
            }


        return false

    }

    fun isCircleWinner(): Boolean {
        for (i in 0 ..kotlin.math.sqrt(boardSize.toDouble()).toInt()){
            for(j in 0 .. kotlin.math.sqrt(boardSize.toDouble()).toInt()){
                 return checkBoard(State.CIRCLE)
            }
        }
        return false
    }

    fun isCrossWinner(): Boolean {
        for (i in 0 ..kotlin.math.sqrt(boardSize.toDouble()).toInt()){
            for(j in 0 .. kotlin.math.sqrt(boardSize.toDouble()).toInt()){
                return checkBoard(State.CROSS)
            }
        }
        return false
    }

    fun updateWinner(){
        if(isCrossWinner()){
            _winner.value = "CROSS IS WINNER "
        }
        if(isCircleWinner()){
            _winner.value = "CIRCLE IS WINNER"
        }

    }


}
