package com.example.circularprogressbar

import android.content.Context
import android.content.res.Resources
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.lang.Math.abs
import java.lang.Math.max
import java.util.*


class CircularProgressBar(context : Context) : View(context) {

    var progress : Float = 0f
    var maxDistance : Int = 0

    var destinationX : Int = 0
    var destinationY : Int = 0



    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

        if(canvas == null){
            return
        }
        val paint = Paint()
        paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 100f
        paint.color = Color.GRAY

        val x = width / 2
        val y = height / 2

        val radius = Math.min(x, y) - 100

        val angleStart = 0f
        val angleEnd: Float =  ((maxDistance-progress) / maxDistance ) * 360f

        canvas.drawCircle(x.toFloat(), y.toFloat(), radius.toFloat(), paint)


        paint.color = Color.RED
        canvas.drawArc(
            (x - radius).toFloat(),
            (y - radius).toFloat(),
            (x + radius).toFloat(), (y + radius).toFloat(), angleStart, angleEnd, false, paint
        )
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {

        progress = abs(event!!.x - destinationX) + abs(event.y - destinationY) - 15f

        invalidate()
        return super.onTouchEvent(event)
    }

    fun generateDestinationPoint(){

        val displayMetrics = Resources.getSystem().displayMetrics

        val width = displayMetrics.widthPixels
        val height = displayMetrics.heightPixels

        val rand = Random()
        destinationX = rand.nextInt(width - 100)
        destinationY = rand.nextInt(height - 100)
        val distance1 = abs(width - destinationX) + abs(height - destinationY)
        val distance2 = abs(0 - destinationX) + abs(0 - destinationY)
        val distance3 = abs(0 - destinationX) + abs(height - destinationY)
        val distance4 = abs(width - destinationX) + abs(0 - destinationY)
        maxDistance = findMax(distance1,distance2,distance3,distance4)
        progress = maxDistance.toFloat()

    }

    private fun findMax(distance1 : Int, distance2 : Int, distance3 : Int, distance4 : Int) : Int{
        val max1 = max(distance1,distance2)
        val max2 = max(distance3,distance4)
        return  max(max1,max2)
    }
}

