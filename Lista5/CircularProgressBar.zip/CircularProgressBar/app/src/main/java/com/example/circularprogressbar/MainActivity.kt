package com.example.circularprogressbar

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout


class MainActivity : AppCompatActivity() {


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val restartButton = findViewById<Button>(R.id.restart)
        val constraintLayout = findViewById<ConstraintLayout>(R.id.constraint)
        restartButton.setOnClickListener {
            val circuralProgressBar = CircularProgressBar(this)
            val layoutParams = ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.MATCH_PARENT,
                ConstraintLayout.LayoutParams.MATCH_PARENT
            )
            circuralProgressBar.layoutParams = layoutParams
            circuralProgressBar.generateDestinationPoint()
            constraintLayout.addView(circuralProgressBar)
        }

    }
}