package com.example.spaceinvaders

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

import java.sql.Date

@Entity
data class Score(

    @PrimaryKey(autoGenerate = true) val id: Int= 0,
    @ColumnInfo(name = "date") val date: Date,
    @ColumnInfo(name = "score") val score: Int

)
