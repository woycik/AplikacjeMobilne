package com.example.spaceinvaders

import android.app.Application

class ScoreApplication : Application() {

    private val database by lazy { ScoreDataBase.getDatabase(this) }
    val repository by lazy { ScoreRepository(database.scoreDao()) }

}