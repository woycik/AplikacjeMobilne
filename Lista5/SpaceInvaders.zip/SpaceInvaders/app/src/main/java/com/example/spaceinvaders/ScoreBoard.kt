package com.example.spaceinvaders

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import androidx.activity.viewModels
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.sql.Date

class ScoreBoard : AppCompatActivity(){
    lateinit var linearLayout : LinearLayout
    private val scoreViewModel: ScoreViewModel by viewModels {
        ScoreModelFactory((application as ScoreApplication).repository)
    }


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score_board)
        linearLayout = findViewById(R.id.linearLayout)
        linearLayout.setBackgroundColor(Color.BLACK)

        val date = Date.valueOf(intent.getStringExtra("Date"))
        val score = intent.getIntExtra("score",0)

        addScore(date,score)

        val back = findViewById<Button>(R.id.button)
        back.setOnClickListener {
            end()
        }
        displayScores()

    }

    @SuppressLint("SetTextI18n")
    fun displayScores(){
        scoreViewModel.scores.observe(this) { scores ->
            for (score in scores) {
                val textView = TextView(this)
                textView.gravity = Gravity.CENTER_HORIZONTAL
                textView.textSize = 20F
                textView.setTextColor(Color.WHITE)
                textView.text = "${score.id}:             ${score.score}              ${score.date}"
                linearLayout.addView(textView)
            }
        }
    }

    fun addScore(date: Date, score : Int){
        val score = Score(0,date,score)
        scoreViewModel.insertScore(score)
    }

    fun deleteAll(){
        scoreViewModel.deleteAllScores()
    }

    fun end(){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

}