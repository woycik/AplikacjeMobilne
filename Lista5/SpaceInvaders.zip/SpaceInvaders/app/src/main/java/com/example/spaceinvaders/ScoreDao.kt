package com.example.spaceinvaders

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScoreDao {
    @Query("SELECT * FROM score")
    fun getAll(): Flow<List<Score>>

    @Insert
    fun insert(score: Score)

    @Insert
    fun insertAll(vararg scores: Score)

    @Delete
    fun delete(score: Score)

    @Query("DELETE FROM score")
    fun deleteAll()
}