package com.example.spaceinvaders

import androidx.annotation.WorkerThread
import kotlinx.coroutines.flow.Flow

class ScoreRepository(private val scoreDao : ScoreDao) {
    val allScores: Flow<List<Score>> = scoreDao.getAll()

    @WorkerThread
    fun insertScore(Score: Score) {
        scoreDao.insert(Score)
    }

    @WorkerThread
    fun insertScores(vararg Scores: Score) {
        scoreDao.insertAll(*Scores)
    }

    @WorkerThread
    fun delete(Score: Score) {
        scoreDao.delete(Score)
    }

    @WorkerThread
    fun deleteAll() {
        scoreDao.deleteAll()
    }

}