package com.example.spaceinvaders

import androidx.lifecycle.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ScoreViewModel(private val repository: ScoreRepository): ViewModel() {
    var scores: LiveData<List<Score>> = repository.allScores.asLiveData()

    fun insertScore(score: Score) = viewModelScope.launch(Dispatchers.IO) {
        repository.insertScore(score)
    }

    fun insertScores(vararg scores: Score) = viewModelScope.launch(Dispatchers.IO)  {
        repository.insertScores(*scores)
    }

    fun deleteScore(score: Score) = viewModelScope.launch(Dispatchers.IO)  {
        repository.delete(score)
    }

    fun deleteAllScores() = viewModelScope.launch(Dispatchers.IO)  {
        repository.deleteAll()
    }

}

class ScoreModelFactory(private val repository: ScoreRepository): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(ScoreViewModel::class.java)) {
            return ScoreViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown class")
    }
}