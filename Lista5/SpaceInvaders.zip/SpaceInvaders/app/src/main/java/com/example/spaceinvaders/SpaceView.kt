package com.example.spaceinvaders

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.appcompat.app.AppCompatActivity
import java.sql.Date


class SpaceView(context : Context) : SurfaceView(context), SurfaceHolder.Callback {

    private var spaceCraft_x : Int = 0
    private var spaceCraft_y : Int = 0

    val displayMetrics = resources.displayMetrics
    private var height = displayMetrics.heightPixels
    private var width = displayMetrics.widthPixels

    var rectLeft : Rect
    var rectRight : Rect
    lateinit var rectSpaceCraft : Rect

    var bullets : ArrayList<Rect> = ArrayList()
    var oponents : ArrayList<Rect> = ArrayList()

    private val thread : gameThread
    private val oponentThread : ThreadOpponent
    private var score = 0

    var shift = width / 30

    init{
        holder.addCallback(this)
        thread = gameThread(holder,this)
        oponentThread = ThreadOpponent(holder,this)

        spaceCraft_x = width/10 * 5 - 75
        spaceCraft_y = height/10 * 8 - 50

        rectLeft = Rect((width/10 * 1),
            (height/10 * 9), ((width/10 * 1) + 300),
            ((height/10 * 9)+150))

        rectRight = Rect((width/10 * 7),
            (height/10 * 9), ((width/10 * 7) + 300),
            ((height/10 * 9)+150))
    }


    override fun surfaceCreated(holder: SurfaceHolder) {
        thread.running = true
        thread.start()
        oponentThread.running = true
        oponentThread.start()

    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {

    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        thread.running = false
        thread.join()

        oponentThread.running = false
        oponentThread.join()

    }


    @SuppressLint("UseCompatLoadingForDrawables")
    override fun draw(canvas : Canvas?){
        super.draw(canvas)
        if(canvas ==null){
            return
        }
        val textPaint = Paint()
        textPaint.color = Color.LTGRAY
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 150f

        canvas.drawText("Score: " + score, (width/2).toFloat(), (height/10).toFloat(),textPaint)
        val p = Paint()
        p.color = Color.TRANSPARENT

        rectSpaceCraft = Rect(
            spaceCraft_x,
            spaceCraft_y,
            (spaceCraft_x + 200),
            (spaceCraft_y + 300)
        )

        //rysowanie statku kosmicznego
        val drawable = context.getDrawable(R.drawable.spacecraft) // get the drawable from resources
        if (drawable != null) {
            drawable.setBounds(
                rectSpaceCraft.left,
                rectSpaceCraft.top,
                (rectSpaceCraft.right),
                (rectSpaceCraft.bottom)
            )
        } // set the bounds of the drawable
        if (drawable != null) {
            drawable.draw(canvas)
        }
        val paint1 = Paint()
        paint1.color = Color.WHITE
        paint1.textAlign = Paint.Align.CENTER
        paint1.textSize = 200f


        //rysowanie przycisków
        val paint = Paint()
        paint.color = Color.BLUE


        canvas.drawRect(rectRight,paint)
        canvas.drawRect(rectLeft,paint)


        canvas.drawText("->", rectRight.left.toFloat() + 150f,
            rectRight.top.toFloat() + 150f,paint1)


        canvas.drawText("<-", rectLeft.left.toFloat() + 150f,
            rectLeft.top.toFloat() + 150f,paint1)


        //narysuj wszystkie naboje
        for(bullet in bullets){
            canvas.drawRect(bullet,paint1)

        }

        //narysuj wszytskich przeciwników
        for(oponent in oponents){
            val ufo = context.getDrawable(R.drawable.ufo)
            ufo?.setBounds(
                oponent.left,
                oponent.top,
                oponent.right,
                oponent.bottom
            ) // set the bounds of the drawable
            ufo?.draw(canvas)
        }




    }


    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y



        if(rectSpaceCraft.contains(x.toInt(), y.toInt())){
            val bullet_x = (rectSpaceCraft.left + rectSpaceCraft.right)/2
            bullets.add(Rect(bullet_x,
                rectSpaceCraft.top + 50,
                bullet_x+ 20,
                rectSpaceCraft.top))
        }

       if(rectLeft.contains(x.toInt(), y.toInt())){
           spaceCraft_x -= 30
       }
        if(rectRight.contains(x.toInt(),y.toInt())){
            spaceCraft_x += 30
        }


        return true
    }

    fun updateOpponentPosition(){
        shift = -1 * shift
        val y = 150
        val x = width / 5 - 25
        for( i in 1 .. 5){
            val curr_x = i * x
            val curr_y =  y
            oponents.add(Rect( curr_x + shift - 150,
                curr_y,
                curr_x  + shift,
                curr_y + 150))
        }

        val opponentForRemove = ArrayList<Rect>();

        for(opponent in oponents){
            opponent.top += 250
            opponent.bottom += 250
            if(opponent.top >= spaceCraft_y){
                endGame()
            }

        }
        oponents.removeAll(opponentForRemove.toSet())
    }

    private fun endGame() {
        thread.running = false
        oponentThread.running = false

        val intent = Intent(context, ScoreBoard::class.java)
        intent.putExtra("score",score)
        intent.putExtra("Date", Date(System.currentTimeMillis()).toString())
        context.startActivity(intent)
        (context as Activity).finish()

    }



    fun updateBulletsPosition(){
        val bulletsToRemove = ArrayList<Rect>()
        val opponentForRemove = ArrayList<Rect>();

        for(bullet in bullets){
            bullet.top -= 100
            bullet.bottom -= 100
            if(bullet.top<0){
                bulletsToRemove.add(bullet)
            }
            for(opponent in oponents) {
                if (opponent.contains(bullet)){
                    opponentForRemove.add(opponent)
                    bulletsToRemove.add(bullet)
                    score ++
                }
            }

        }
        bullets.removeAll(bulletsToRemove.toSet())
        oponents.removeAll(opponentForRemove.toSet())
    }
}