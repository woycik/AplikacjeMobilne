package com.example.spaceinvaders

import android.view.SurfaceHolder


class ThreadOpponent(private val surfaceHolder : SurfaceHolder, private val gameView : SpaceView) : Thread() {

    var running = false

    override fun run(){
        while(running) {
            synchronized(surfaceHolder) {
                gameView.updateOpponentPosition()
            }

            sleep(1500)

        }
    }

}