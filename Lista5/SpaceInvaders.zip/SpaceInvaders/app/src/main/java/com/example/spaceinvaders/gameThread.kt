package com.example.spaceinvaders

import android.view.SurfaceHolder

class gameThread(private val surfaceHolder : SurfaceHolder, private val gameView : SpaceView) : Thread() {
    var running = false

    override fun run(){
        while(running) {
            val canvas = surfaceHolder.lockCanvas()
            synchronized(surfaceHolder) {
                gameView.draw(canvas)
                gameView.updateBulletsPosition()
            }
            gameView.holder.unlockCanvasAndPost(canvas)
            sleep(15)
        }
    }
}