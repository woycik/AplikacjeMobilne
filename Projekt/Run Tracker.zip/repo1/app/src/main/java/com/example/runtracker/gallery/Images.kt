package com.example.runtracker.gallery

class Images(var path: String, var data: String)