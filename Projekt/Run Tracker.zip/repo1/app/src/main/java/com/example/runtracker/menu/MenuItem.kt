package com.example.runtracker.menu

class MenuItem(var data: String, var drawable: Int)