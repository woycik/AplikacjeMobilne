package com.example.runtracker.myAccount

class MyAccountItem(val item: String, val appWidget: String)