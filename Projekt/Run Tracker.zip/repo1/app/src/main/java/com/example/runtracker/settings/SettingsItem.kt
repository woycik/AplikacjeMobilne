package com.example.runtracker


class settingsItem(var text: String, var icon : Int, var showSwith : Boolean) {
}
